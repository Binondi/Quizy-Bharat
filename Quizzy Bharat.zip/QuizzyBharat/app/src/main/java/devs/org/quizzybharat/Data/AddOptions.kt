package devs.org.quizzybharat.Data

class AddOptions(var list:ArrayList<String>) {

}