package devs.org.quizzybharat.Data

class ViewsData(var key:String) {

    constructor():this("")

}