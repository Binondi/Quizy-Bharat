package devs.org.quizzybharat.Data

class Heading(var heading: List<QuestionData>) {
    constructor() : this(emptyList())
}
